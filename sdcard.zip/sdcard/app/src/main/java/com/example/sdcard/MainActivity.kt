package com.example.sdcard
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.io.FileWriter

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val reg:EditText=findViewById(R.id.reg)
        val name:EditText=findViewById(R.id.name)
        val cgpa:EditText=findViewById(R.id.cgpa)
        val btn1:Button=findViewById(R.id.btn1)
        val btn2:Button=findViewById(R.id.btn2)
        btn1.setOnClickListener {
            val reg1 = reg.text.toString();
            val name1 = name.text.toString();
            val cgpa1 = cgpa.text.toString();
            val file = File(getExternalFilesDir(null), "students.txt")
            val writer = FileWriter(file)
            writer.write("$reg1\n$name1\n$cgpa1")
            writer.close();
            reg.text.clear()
            name.text.clear()
            cgpa.text.clear()
            Toast.makeText(this, "saved successfully", Toast.LENGTH_LONG).show()
        }
        btn2.setOnClickListener {
            val file = File(getExternalFilesDir(null), "students.txt")
            val reader = BufferedReader(FileReader(file))
            val reg2=reader.readLine()
            val name2=reader.readLine()
            val cgpa2=reader.readLine()
            reg.setText(reg2)
            reg.setText(name2)
            reg.setText(cgpa2)
            reader.close()
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }


}