package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val weight: EditText = findViewById(R.id.weight)
        val height: EditText = findViewById(R.id.height)
        val result: EditText = findViewById(R.id.result)
        val btn1: Button = findViewById(R.id.btn1)

        btn1.setOnClickListener {
            val w = weight.text.toString().toIntOrNull() ?: 0
            val h = height.text.toString().toIntOrNull() ?: 0
            if (h == 0) {
                result.setText("Height cannot be 0")
            } else {
                val res = (w.toFloat()) / (h * h.toFloat())
                result.setText(res.toString())
            }
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
